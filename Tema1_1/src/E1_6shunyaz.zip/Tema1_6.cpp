//============================================================================
// Name        : Tema1_6.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main()
{
	int numero;
	cout<<"Introduzca 5 numeros:";
	cin>>numero;
	cout<<"El ultimo numero es:"<<(numero % 10)<<endl;



	return 0;
}
